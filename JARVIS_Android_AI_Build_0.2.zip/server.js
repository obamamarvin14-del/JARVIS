import "dotenv/config";
import express from "express";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import OpenAI from "openai";

const app = express();
const port = Number(process.env.PORT || 3000);
const apiKey = process.env.OPENAI_API_KEY;
const model = process.env.OPENAI_MODEL || "gpt-6-astra";

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "32kb" }));
app.use(express.static("public"));

app.get("/api/health", (_req, res) => res.json({ ok: true, configured: Boolean(apiKey) }));
app.use("/api/chat", rateLimit({
  windowMs: 60_000, limit: 20, standardHeaders: "draft-7", legacyHeaders: false,
  message: { error: "Too many requests. Please wait a moment, Sir." }
}));

app.post("/api/chat", async (req, res) => {
  if (!apiKey) return res.status(503).json({ error: "The AI key has not been configured on the server yet." });
  const messages = req.body?.messages;
  if (!Array.isArray(messages) || messages.length < 1 || messages.length > 12)
    return res.status(400).json({ error: "Send between 1 and 12 recent messages." });

  const safeMessages = [];
  for (const m of messages) {
    if (!m || !["user", "assistant"].includes(m.role) ||
        typeof m.content !== "string" || m.content.length > 3000)
      return res.status(400).json({ error: "A message is invalid or too long." });
    safeMessages.push({ role: m.role, content: m.content });
  }

  try {
    const client = new OpenAI({ apiKey });
    const result = await client.responses.create({
      model,
      instructions: [
        "You are J.A.R.V.I.S., a helpful personal assistant.",
        "Address the user respectfully as Sir. Occasionally say Boss in a casual context, but do not overuse either.",
        "Use natural British English. Be calm, concise, thoughtful and honest.",
        "Never claim to control the phone, access private data, remember information permanently, or perform actions unless an available tool actually did so.",
        "Ask permission before consequential actions. Respect privacy and safety."
      ].join(" "),
      input: safeMessages
    });
    const reply = result.output_text?.trim();
    if (!reply) return res.status(502).json({ error: "The AI returned an empty response." });
    res.json({ reply });
  } catch (err) {
    console.error("AI request failed:", err?.status || err?.name || "unknown");
    res.status(502).json({ error: "I couldn't reach the AI service just now, Sir. Please try again." });
  }
});

app.listen(port, () => console.log(`JARVIS server listening on port ${port}`));
