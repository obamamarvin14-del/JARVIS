# JARVIS Android AI — Build 0.2

## What this build adds
- Real AI responses through the OpenAI Responses API
- JARVIS personality: British English, addresses the user as Sir and occasionally Boss
- Voice recognition and spoken replies through browser speech APIs
- Current-page conversation context (last 12 messages)
- Server-side API key, input validation, request size limits, security headers and basic rate limiting

## Run on a computer
Requires Node.js 20+.
1. Copy `.env.example` to `.env`.
2. Set `OPENAI_API_KEY` in `.env` (never commit `.env`).
3. Optionally set `OPENAI_MODEL` to a model available to your API project.
4. Run `npm install`.
5. Run `npm start`.
6. Open `http://localhost:3000`.

## Put it online for Android
Deploy this Node.js project to a trusted HTTPS host that supports Node. Configure `OPENAI_API_KEY` and optionally `OPENAI_MODEL` using the host's private environment-variable settings. The `public/` directory is served by Express. Open the HTTPS address in Chrome on Android and allow microphone access.

GitHub Pages alone cannot run `server.js`; it only hosts static files. The backend needs a Node-capable host.

## Important
- API use may incur charges and is separate from a ChatGPT subscription.
- If account or billing setup requires an adult, ask a parent or guardian to manage it. Do not share API credentials in chat or commit them to GitHub.
- Conversation context currently lasts only while the page is open. A persistent memory database is a later feature.
- Speech recognition varies by browser/device and may require internet.
- This is not yet a native APK or an always-listening background assistant.
